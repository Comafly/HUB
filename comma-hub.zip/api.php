<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

const DATA_FILE = __DIR__ . '/data/app.json';
const UPLOAD_DIR = __DIR__ . '/uploads';
const UPLOAD_URL = 'uploads';

function response(mixed $data = null, int $status = 200): never {
    http_response_code($status);
    echo json_encode(['ok' => $status < 400, 'data' => $data], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}
function fail(string $message, int $status = 400): never {
    http_response_code($status);
    echo json_encode(['ok' => false, 'error' => $message], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}
function ensureStorage(): void {
    if (!is_dir(dirname(DATA_FILE))) mkdir(dirname(DATA_FILE), 0775, true);
    if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0775, true);
    if (!file_exists(DATA_FILE)) file_put_contents(DATA_FILE, json_encode(defaultData(), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
}
function defaultData(): array {
    return [
        'tiles' => [
            ['id'=>'seed-1','section'=>'dashboard','type'=>'link','label'=>'COMMA Team Showcase','description'=>'Selected work, references, and current directions.','tags'=>['Design'],'size'=>'large','orientation'=>'landscape','url'=>'https://example.com','thumbnail'=>'','createdAt'=>date(DATE_ATOM)],
            ['id'=>'seed-2','section'=>'dashboard','type'=>'text','label'=>'Today / 01','description'=>'Keep the board loose. Save references first; sort them later.','tags'=>['Typography'],'size'=>'small','orientation'=>'portrait','text'=>'COLLECT\nFIRST.\nCURATE\nSECOND.','textStyle'=>['font'=>'Arial, sans-serif','fontSize'=>31,'bold'=>true,'italic'=>false,'underline'=>false,'align'=>'left'],'createdAt'=>date(DATE_ATOM)],
            ['id'=>'seed-3','section'=>'dashboard','type'=>'link','label'=>'Motion reference','description'=>'Timing and transition notes for interface motion.','tags'=>['Animation'],'size'=>'medium','orientation'=>'portrait','url'=>'https://www.awwwards.com','thumbnail'=>'','createdAt'=>date(DATE_ATOM)],
            ['id'=>'seed-4','section'=>'projects','type'=>'text','label'=>'Project board','description'=>'Working notes for active builds.','tags'=>['Design'],'size'=>'medium','orientation'=>'landscape','text'=>'COMMA / PROJECTS','textStyle'=>['font'=>'Arial, sans-serif','fontSize'=>36,'bold'=>true,'italic'=>false,'underline'=>false,'align'=>'left'],'createdAt'=>date(DATE_ATOM)],
            ['id'=>'seed-5','section'=>'resources','type'=>'text','label'=>'Type specimen notes','description'=>'Useful typography references and foundry links.','tags'=>['Typography'],'size'=>'medium','orientation'=>'portrait','text'=>'Aa\nTYPE\nINDEX','textStyle'=>['font'=>'Georgia, serif','fontSize'=>42,'bold'=>true,'italic'=>false,'underline'=>false,'align'=>'left'],'createdAt'=>date(DATE_ATOM)],
        ],
        'topLinks' => [],
        'bookmarks' => ['seed-1','seed-3'],
        'settings' => ['theme'=>'umber','mode'=>'dark'],
    ];
}
function readData(): array {
    ensureStorage();
    $fp = fopen(DATA_FILE, 'c+');
    if (!$fp) fail('Unable to open data file', 500);
    flock($fp, LOCK_SH);
    $json = stream_get_contents($fp) ?: '{}';
    flock($fp, LOCK_UN);
    fclose($fp);
    return array_replace_recursive(defaultData(), json_decode($json, true) ?: []);
}
function mutateData(callable $callback): mixed {
    ensureStorage();
    $fp = fopen(DATA_FILE, 'c+');
    if (!$fp) fail('Unable to open data file', 500);
    flock($fp, LOCK_EX);
    $json = stream_get_contents($fp) ?: '{}';
    $data = array_replace_recursive(defaultData(), json_decode($json, true) ?: []);
    $result = $callback($data);
    ftruncate($fp, 0); rewind($fp);
    fwrite($fp, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    fflush($fp); flock($fp, LOCK_UN); fclose($fp);
    return $result;
}
function bodyJson(): array {
    $raw = file_get_contents('php://input') ?: '{}';
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}
function id(string $prefix): string { return $prefix . '-' . bin2hex(random_bytes(6)); }
function cleanTags(string $value): array {
    $parts = array_filter(array_map('trim', explode(',', $value)));
    return array_values(array_unique(array_slice($parts, 0, 12)));
}
function storeUpload(array $file): ?string {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) return null;
    $name = basename((string)$file['name']);
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $safeExt = preg_replace('/[^a-z0-9]/', '', $ext);
    $filename = bin2hex(random_bytes(10)) . ($safeExt ? '.' . $safeExt : '');
    $destination = UPLOAD_DIR . '/' . $filename;
    if (!move_uploaded_file($file['tmp_name'], $destination)) fail('Upload failed', 500);
    return UPLOAD_URL . '/' . $filename;
}
function normalizedFiles(string $field): array {
    if (!isset($_FILES[$field])) return [];
    $input = $_FILES[$field];
    if (!is_array($input['name'])) return [$input];
    $files = [];
    foreach ($input['name'] as $i => $name) {
        $files[] = ['name'=>$name,'type'=>$input['type'][$i] ?? '','tmp_name'=>$input['tmp_name'][$i] ?? '','error'=>$input['error'][$i] ?? UPLOAD_ERR_NO_FILE,'size'=>$input['size'][$i] ?? 0];
    }
    return $files;
}
function storeMany(string ...$fields): array {
    $paths = [];
    foreach ($fields as $field) foreach (normalizedFiles($field) as $file) { $stored = storeUpload($file); if ($stored) $paths[] = $stored; }
    return $paths;
}

$action = $_GET['action'] ?? 'bootstrap';

try {
    switch ($action) {
        case 'bootstrap': response(readData());

        case 'settings.update':
            $input = bodyJson();
            $settings = [
                'theme' => in_array(($input['theme'] ?? 'umber'), ['umber','midnight-blue','bubblegum','caramel','marble'], true) ? $input['theme'] : 'umber',
                'mode' => in_array(($input['mode'] ?? 'dark'), ['dark','light'], true) ? $input['mode'] : 'dark',
            ];
            mutateData(function (&$data) use ($settings) { $data['settings'] = $settings; });
            response($settings);

        case 'tiles.create':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('POST required', 405);
            $type = preg_replace('/[^a-z]/', '', $_POST['type'] ?? 'file');
            $tile = [
                'id'=>id('tile'), 'section'=>in_array($_POST['section'] ?? '', ['dashboard','projects','resources'], true) ? $_POST['section'] : 'dashboard',
                'type'=>$type, 'label'=>trim($_POST['label'] ?? ''), 'description'=>trim($_POST['description'] ?? ''),
                'tags'=>cleanTags($_POST['tags'] ?? ''), 'size'=>in_array($_POST['size'] ?? '', ['small','medium','large'], true) ? $_POST['size'] : 'medium',
                'orientation'=>in_array($_POST['orientation'] ?? '', ['landscape','portrait'], true) ? $_POST['orientation'] : 'landscape', 'createdAt'=>date(DATE_ATOM),
            ];
            $files = storeMany('draggedFiles', 'files');
            $thumbnail = normalizedFiles('thumbnail');
            $thumbPath = $thumbnail ? storeUpload($thumbnail[0]) : null;
            if ($files) $tile['files'] = $files;
            if ($thumbPath) $tile['thumbnail'] = $thumbPath;
            if ($type === 'link') { $tile['url'] = filter_var($_POST['url'] ?? '', FILTER_SANITIZE_URL); if (!$tile['url']) fail('A URL is required'); }
            if ($type === 'text') {
                $tile['text'] = $_POST['text'] ?? '';
                $tile['textStyle'] = ['font'=>trim($_POST['font'] ?? 'Arial, sans-serif'),'fontSize'=>(int)($_POST['fontSize'] ?? 28),'bold'=>isset($_POST['bold']),'italic'=>isset($_POST['italic']),'underline'=>isset($_POST['underline']),'align'=>in_array($_POST['align'] ?? '', ['left','center','right'], true) ? $_POST['align'] : 'left'];
            }
            mutateData(function (&$data) use ($tile) { array_unshift($data['tiles'], $tile); });
            response($tile, 201);

        case 'tiles.delete':
            $input = bodyJson(); $tileId = (string)($input['id'] ?? ''); if (!$tileId) fail('Missing tile id');
            mutateData(function (&$data) use ($tileId) {
                $data['tiles'] = array_values(array_filter($data['tiles'], fn($tile) => ($tile['id'] ?? '') !== $tileId));
                $data['bookmarks'] = array_values(array_filter($data['bookmarks'], fn($id) => $id !== $tileId));
            }); response(['id'=>$tileId]);

        case 'toplinks.create':
            $label = trim($_POST['label'] ?? ''); $url = filter_var($_POST['url'] ?? '', FILTER_SANITIZE_URL);
            if (!$label || !$url) fail('Label and URL are required');
            $imageFiles = normalizedFiles('image'); $image = $imageFiles ? storeUpload($imageFiles[0]) : null;
            $link = ['id'=>id('link'),'label'=>$label,'url'=>$url,'image'=>$image ?: ''];
            mutateData(function (&$data) use ($link) { $data['topLinks'][] = $link; }); response($link, 201);

        case 'toplinks.delete':
            $input = bodyJson(); $linkId = (string)($input['id'] ?? '');
            mutateData(function (&$data) use ($linkId) { $data['topLinks'] = array_values(array_filter($data['topLinks'], fn($link) => ($link['id'] ?? '') !== $linkId)); }); response(['id'=>$linkId]);

        case 'bookmarks.update':
            $ids = bodyJson()['ids'] ?? []; if (!is_array($ids)) fail('ids must be an array');
            mutateData(function (&$data) use ($ids) {
                $known = array_column($data['tiles'], 'id');
                $data['bookmarks'] = array_values(array_unique(array_filter($ids, fn($id) => in_array($id, $known, true))));
            }); response($ids);

        default: fail('Unknown action', 404);
    }
} catch (Throwable $e) {
    fail($e->getMessage(), 500);
}
