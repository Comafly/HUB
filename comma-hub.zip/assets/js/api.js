const API_URL = 'api.php';

async function request(action, options = {}) {
  const { method = 'GET', body, params = {} } = options;
  const url = new URL(API_URL, window.location.href);
  url.searchParams.set('action', action);
  Object.entries(params).forEach(([key, value]) => url.searchParams.set(key, value));

  const response = await fetch(url, { method, body });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.ok === false) {
    throw new Error(payload.error || `Request failed (${response.status})`);
  }
  return payload.data ?? payload;
}

export const api = {
  bootstrap: () => request('bootstrap'),
  saveSettings: (settings) => request('settings.update', {
    method: 'POST',
    body: JSON.stringify(settings),
  }),
  createTile: (formData) => request('tiles.create', { method: 'POST', body: formData }),
  deleteTile: (id) => request('tiles.delete', { method: 'POST', body: JSON.stringify({ id }) }),
  createTopLink: (formData) => request('toplinks.create', { method: 'POST', body: formData }),
  deleteTopLink: (id) => request('toplinks.delete', { method: 'POST', body: JSON.stringify({ id }) }),
  saveBookmarks: (ids) => request('bookmarks.update', { method: 'POST', body: JSON.stringify({ ids }) }),
};
