import { api } from './api.js';

const TAGS = ['All', 'Photography', 'Film', 'Animation', 'Audio', 'Design', 'Typography'];
const PRESET_TAGS = TAGS.slice(1);
const SECTION_COPY = {
  dashboard: ['Dashboard', 'A living board for today’s references, media, notes, and working files.'],
  projects: ['Projects', 'Active project material, deliverables, and references in one adaptable workspace.'],
  resources: ['Resources', 'Reusable references, inspiration, assets, files, and links.'],
};
const MEDIA_TYPES = new Set(['image', 'video', 'audio', 'text', 'file', 'font']);
const state = {
  tiles: [], topLinks: [], bookmarks: [], settings: { theme: 'umber', mode: 'dark' },
  section: 'dashboard', tag: 'All', query: '', pendingDrop: null, pendingThumbnail: null, pendingTags: [], previewUrls: [],
};
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const els = {
  tileGrid: $('#tileGrid'), tagList: $('#tagList'), search: $('#searchInput'), clearSearch: $('#clearSearch'),
  topLinks: $('#topLinks'), bookmarks: $('#bookmarkList'), bookmarkCount: $('#bookmarkCount'),
  contentModal: $('#contentModal'), contentForm: $('#contentForm'), dynamicFields: $('#dynamicFields'),
  contentTypeEyebrow: $('#contentTypeEyebrow'), contentModalTitle: $('#contentModalTitle'),
  topLinkModal: $('#topLinkModal'), topLinkForm: $('#topLinkForm'), settingsModal: $('#settingsModal'),
  settingsButton: $('#settingsButton'), modeToggle: $('#modeToggle'), modeLabel: $('#modeLabel'),
  dragOverlay: $('#dragOverlay'), emptyState: $('#emptyState'), sectionTitle: $('#sectionTitle'),
  sectionDescription: $('#sectionDescription'), toastRegion: $('#toastRegion'), bookmarksPanel: $('#bookmarksPanel'),
  contentAddButton: $('#contentAddButton'), contentFilePicker: $('#contentFilePicker'), contentTypeModal: $('#contentTypeModal'), tagEditor: $('#tagEditor'),
  tagCapsules: $('#tagCapsules'), tagInput: $('#tagInput'), presetTags: $('#presetTags'),
  mediaViewer: $('#mediaViewer'), viewerMedia: $('#viewerMedia'), viewerMeta: $('#viewerMeta'),
};

function escapeHtml(value = '') { return String(value).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c])); }
function toast(message, tone='default') { const el=document.createElement('div'); el.className=`toast toast--${tone}`; el.textContent=message; els.toastRegion.appendChild(el); requestAnimationFrame(()=>el.classList.add('is-visible')); setTimeout(()=>{el.classList.remove('is-visible');setTimeout(()=>el.remove(),250)},2600); }
function favicon(url){ try{return `https://www.google.com/s2/favicons?domain=${encodeURIComponent(new URL(url).hostname)}&sz=128`;}catch{return '';} }
function safeHostname(url){ try{return new URL(url).hostname.replace(/^www\./,'');}catch{return url||'';} }
function defaultTileLabel(tile){ if(tile.type==='link')return safeHostname(tile.url); if(tile.type==='text')return 'Text note'; if(tile.files?.length)return tile.files[0].split('/').pop(); return 'Untitled'; }

function renderTags(){ els.tagList.innerHTML=TAGS.map(tag=>`<button class="tag-btn ${state.tag===tag?'is-active':''}" data-tag="${tag}">${tag}<span>↗</span></button>`).join(''); }
function tileMatches(tile){ const section=tile.section===state.section; const tag=state.tag==='All'||(tile.tags||[]).some(x=>x.toLowerCase()===state.tag.toLowerCase()); const hay=[tile.label,tile.description,tile.text,tile.url,...(tile.tags||[])].filter(Boolean).join(' ').toLowerCase(); return section&&tag&&(!state.query||hay.includes(state.query.toLowerCase())); }
function tileMedia(tile){
  if(tile.type==='text'&&tile.thumbnail)return `<img class="cover" src="${escapeHtml(tile.thumbnail)}" alt="" />`;
  if(tile.type==='text'){const s=tile.textStyle||{};return `<div class="text-tile" style="font-family:${escapeHtml(s.font||'inherit')};font-size:${Number(s.fontSize||28)}px;font-weight:${s.bold?700:500};font-style:${s.italic?'italic':'normal'};text-decoration:${s.underline?'underline':'none'};text-align:${escapeHtml(s.align||'left')}">${escapeHtml(tile.text||'')}</div>`;}
  if(tile.type==='image'&&tile.files?.length){const imgs=tile.files.slice(0,4).map((src,i)=>`<img src="${escapeHtml(src)}" alt="${escapeHtml(tile.label||`Image ${i+1}`)}" />`).join('');return `<div class="gallery gallery--${Math.min(tile.files.length,4)}">${imgs}</div>`;}
  if(tile.type==='video'&&tile.files?.[0])return `<video src="${escapeHtml(tile.files[0])}" muted loop playsinline preload="metadata"></video>`;
  if((tile.type==='audio'||tile.type==='file'||tile.type==='font')&&tile.thumbnail)return `<img class="cover" src="${escapeHtml(tile.thumbnail)}" alt="" />`;
  if(tile.type==='link'){const thumb=tile.thumbnail||favicon(tile.url);return `<div class="link-preview">${thumb?`<img src="${escapeHtml(thumb)}" alt="" />`:''}<div class="link-domain">${escapeHtml(safeHostname(tile.url))}</div></div>`;}
  return `<div class="file-symbol">${tile.type==='audio'?'♪':tile.type==='font'?'Aa':'↗'}</div>`;
}
function renderTiles(){ const items=state.tiles.filter(tileMatches); els.tileGrid.innerHTML=items.map(tile=>`<article class="tile tile--${escapeHtml(tile.size||'medium')} tile--${escapeHtml(tile.orientation||'landscape')}" draggable="true" data-tile-id="${escapeHtml(tile.id)}" tabindex="0"><div class="tile-media">${tileMedia(tile)}</div><div class="tile-gradient"></div><div class="tile-actions"><button class="tile-action" data-delete-tile="${escapeHtml(tile.id)}" aria-label="Delete tile">×</button></div><div class="tile-content"><h3>${escapeHtml(tile.label||defaultTileLabel(tile))}</h3></div></article>`).join(''); els.emptyState.hidden=items.length>0; }
function renderTopLinks(){els.topLinks.innerHTML=state.topLinks.map(link=>{const image=link.image||favicon(link.url);return `<a class="circle-link" href="${escapeHtml(link.url)}" target="_blank" rel="noreferrer" data-tooltip="${escapeHtml(link.label)}" aria-label="${escapeHtml(link.label)}">${image?`<img src="${escapeHtml(image)}" alt="" />`:'<span>↗</span>'}</a>`;}).join('')+`<button class="circle-link circle-link--add" id="addTopLink" data-tooltip="Add top link" aria-label="Add top link">+</button>`;}
function renderBookmarks(){const byId=new Map(state.tiles.map(t=>[t.id,t]));const existing=state.bookmarks.filter(id=>byId.has(id));state.bookmarks=existing;els.bookmarkCount.textContent=existing.length;els.bookmarks.innerHTML=existing.map((id,index)=>{const tile=byId.get(id);return `<div class="bookmark-item" draggable="true" data-bookmark-id="${escapeHtml(id)}" data-index="${index}"><span class="bookmark-grip">⋮⋮</span><div><strong>${escapeHtml(tile.label||defaultTileLabel(tile))}</strong><small>${escapeHtml(tile.type)}</small></div><button class="bookmark-remove" data-remove-bookmark="${escapeHtml(id)}" aria-label="Remove bookmark">×</button></div>`;}).join('')||`<div class="bookmark-empty"><span>↘</span><p>Drop tiles here</p></div>`;}
function renderAll(){renderTags();renderTiles();renderTopLinks();renderBookmarks();}
function applyTheme(){const theme=state.settings.theme||'umber';const mode=state.settings.mode||'dark';document.documentElement.dataset.theme=theme;document.documentElement.dataset.mode=mode;const dark=mode!=='light';els.modeToggle.checked=dark;els.modeLabel.textContent=dark?'Dark mode':'Light mode';$$('[data-theme-choice]').forEach(card=>{const active=card.dataset.themeChoice===theme;card.classList.toggle('is-active',active);card.setAttribute('aria-pressed',String(active));});}
function setSection(section){state.section=section;$$('.nav-tab').forEach(btn=>btn.classList.toggle('is-active',btn.dataset.section===section));const [title,description]=SECTION_COPY[section];els.sectionTitle.textContent=title;els.sectionDescription.textContent=description;renderTiles();}

function revokePreviewUrls(){state.previewUrls.forEach(URL.revokeObjectURL);state.previewUrls=[];}
function filePreviewUrl(file){const u=URL.createObjectURL(file);state.previewUrls.push(u);return u;}
function pendingFiles(){return state.pendingDrop?.files||[];}
function detectFileType(file){if(file.type.startsWith('image/'))return'image';if(file.type.startsWith('video/'))return'video';if(file.type.startsWith('audio/'))return'audio';if(/\.(ttf|otf|woff2?)$/i.test(file.name))return'font';return'file';}
function detectFiles(files){const arr=[...files];if(!arr.length)return null;const types=arr.map(detectFileType);return{type:types.every(t=>t==='image')?'image':types[0],files:arr};}
function detectDrop(dt){const fileDrop=detectFiles(dt.files||[]);if(fileDrop)return fileDrop;const uri=dt.getData('text/uri-list')||'';const plain=dt.getData('text/plain')||'';const candidate=uri||plain;if(/^https?:\/\//i.test(candidate.trim()))return{type:'link',url:candidate.trim()};if(plain.trim())return{type:'text',text:plain};return null;}

function renderTagEditor(){els.tagCapsules.innerHTML=state.pendingTags.map(tag=>`<span class="tag-capsule">${escapeHtml(tag)}<button class="capsule-x" type="button" data-remove-form-tag="${escapeHtml(tag)}" aria-label="Remove ${escapeHtml(tag)}">×</button></span>`).join('');els.contentForm.elements.tags.value=state.pendingTags.join(',');els.presetTags.innerHTML=PRESET_TAGS.map(tag=>`<button type="button" class="preset-tag ${state.pendingTags.some(t=>t.toLowerCase()===tag.toLowerCase())?'is-added':''}" data-preset-tag="${tag}">${tag}</button>`).join('');}
function normalizeTag(raw){return raw.trim().replace(/^,+|,+$/g,'').replace(/\s+/g,' ');}
function addTag(raw){const tag=normalizeTag(raw);if(!tag)return;if(!state.pendingTags.some(t=>t.toLowerCase()===tag.toLowerCase()))state.pendingTags.push(tag);renderTagEditor();}
function commitTagInput(){const raw=els.tagInput.value;if(raw.trim())addTag(raw);els.tagInput.value='';}

function customUploadMarkup({id,name='',accept='',label='Choose file',multiple=false,helper=''}){
  return `<div class="custom-upload"><input id="${id}" ${name?`name="${name}"`:''} type="file" ${accept?`accept="${accept}"`:''} ${multiple?'multiple':''} hidden><button class="upload-button" type="button" data-file-trigger="${id}"><span class="upload-button-icon">＋</span><span>${label}</span></button><span class="upload-file-name" data-file-name="${id}">No file selected</span></div>${helper?`<small>${helper}</small>`:''}`;
}
function singleImagePickerMarkup(file=state.pendingThumbnail){
  const thumb=file?`<div class="gallery-thumb"><img src="${filePreviewUrl(file)}" alt="${escapeHtml(file.name||'Thumbnail')}"><button type="button" class="capsule-x gallery-remove" data-remove-thumbnail aria-label="Remove thumbnail">×</button></div>`:'';
  return `<div class="gallery-picker gallery-picker--single">${thumb}<button type="button" class="gallery-add" id="thumbnailAdd" aria-label="Add thumbnail"><span class="image-placeholder">▧</span><b>+</b></button></div><input id="thumbnailPickerInput" type="file" accept="image/*" hidden>`;
}
function selectedMediaMarkup(type){const files=pendingFiles();if(type==='image'){return `<div class="gallery-picker" id="galleryPicker">${files.map((f,i)=>`<div class="gallery-thumb"><img src="${filePreviewUrl(f)}" alt="${escapeHtml(f.name)}"><button type="button" class="capsule-x gallery-remove" data-remove-pending-file="${i}" aria-label="Remove image">×</button></div>`).join('')}<button type="button" class="gallery-add" id="galleryAdd" aria-label="Add images"><span class="image-placeholder">▧</span><b>+</b></button></div><input id="galleryFileInput" type="file" accept="image/*" multiple hidden>`;}
  if(files.length){const f=files[0];return `<div class="selected-file"><span class="selected-file-icon">${type==='video'?'▶':type==='audio'?'♪':type==='font'?'Aa':'↗'}</span><div><strong>${escapeHtml(f.name)}</strong><small>${Math.max(1,Math.round(f.size/1024)).toLocaleString()} KB · already selected</small></div></div>`;}
  return '';
}
function textPreviewMarkup(pending={}){
  return `<div class="field field--wide"><span>Text preview</span><div class="text-live-preview" id="textLivePreview">${escapeHtml(pending.text||'Start typing to preview your tile.')}</div></div>`;
}
function fieldMarkup(type,pending={}){
  const media=selectedMediaMarkup(type);
  if(type==='media')return `<div class="field field--wide"><span>Media</span><div class="media-empty-drop"><strong>Drop media here</strong><small>Drag files into this modal, paste an image, or choose files manually.</small><button class="upload-button" type="button" id="chooseMediaButton"><span class="upload-button-icon">＋</span><span>Choose media</span></button></div></div>`;
  if(type==='link')return `<label class="field field--wide"><span>URL</span><input name="url" type="url" required value="${escapeHtml(pending.url||'')}" /></label><div class="field field--wide"><span>Thumbnail image</span>${singleImagePickerMarkup()}</div>`;
  if(type==='text')return `<label class="field field--wide"><span>Text</span><textarea name="text" rows="7" required>${escapeHtml(pending.text||'')}</textarea></label><label class="field"><span>Font</span><select name="font"><option value="Arial, sans-serif">Arial</option><option value="Helvetica, Arial, sans-serif">Helvetica</option><option value="Georgia, serif">Georgia</option><option value="'Times New Roman', serif">Times New Roman</option><option value="Verdana, sans-serif">Verdana</option><option value="Tahoma, sans-serif">Tahoma</option><option value="'Trebuchet MS', sans-serif">Trebuchet MS</option><option value="'Courier New', monospace">Courier New</option><option value="Impact, sans-serif">Impact</option><option value="system-ui, sans-serif">System UI</option></select></label><label class="field"><span>Size</span><input name="fontSize" type="number" min="12" max="96" value="28" /></label><div class="field field--wide"><span>Style</span><div class="format-row"><label class="format-toggle"><input name="bold" type="checkbox" /><span>B</span></label><label class="format-toggle"><input name="italic" type="checkbox" /><span><i>I</i></span></label><label class="format-toggle"><input name="underline" type="checkbox" /><span><u>U</u></span></label><select name="align"><option value="left">Left</option><option value="center">Center</option><option value="right">Right</option></select></div></div><div class="field field--wide"><span>Thumbnail image</span>${singleImagePickerMarkup()}</div>${textPreviewMarkup(pending)}`;
  if(type==='image')return `<div class="field field--wide"><span>Gallery images</span>${media}<small>Drop or paste images anywhere in this modal to add them to the gallery.</small></div>`;
  const accept=type==='video'?'video/*':type==='audio'?'audio/*':type==='font'?'.ttf,.otf,.woff,.woff2':'';
  const mediaLabel=type==='video'?'Video':type==='audio'?'Audio':type==='font'?'Font file':'File';
  const picker=filesRequired(type)?customUploadMarkup({id:'replacementFileInput',accept,label:`Choose ${mediaLabel.toLowerCase()}`}):'';
  return `<div class="field field--wide"><span>${mediaLabel}</span>${media}${picker}</div><div class="field field--wide"><span>Tile image</span>${singleImagePickerMarkup()}</div>`;
}
function filesRequired(type){return !pendingFiles().length&&['video','audio','font','file'].includes(type);}
function refreshDynamicFields(){revokePreviewUrls();els.dynamicFields.innerHTML=fieldMarkup(state.pendingDrop.type,state.pendingDrop);els.contentForm.elements.type.value=state.pendingDrop.type;if(state.pendingDrop.type==='text')updateTextPreview();}

function updateTextPreview(){if(state.pendingDrop?.type!=='text')return;const preview=$('#textLivePreview');if(!preview)return;const f=els.contentForm.elements;preview.textContent=f.text?.value||'Start typing to preview your tile.';preview.style.fontFamily=f.font?.value||'Arial, sans-serif';preview.style.fontSize=`${Number(f.fontSize?.value||28)}px`;preview.style.fontWeight=f.bold?.checked?'700':'500';preview.style.fontStyle=f.italic?.checked?'italic':'normal';preview.style.textDecoration=f.underline?.checked?'underline':'none';preview.style.textAlign=f.align?.value||'left';}
function openContentModal(pending){revokePreviewUrls();state.pendingDrop={...pending,files:[...(pending.files||[])]};state.pendingThumbnail=null;state.pendingTags=[];els.contentForm.reset();els.contentForm.elements.section.value=state.section;els.contentForm.elements.type.value=pending.type;els.contentTypeEyebrow.textContent=`${pending.type} content`;els.contentModalTitle.textContent=`Add ${pending.type}`;refreshDynamicFields();renderTagEditor();els.contentModal.showModal();}

async function handleContentSubmit(event){event.preventDefault();if(state.pendingDrop?.type==='media'){toast('Choose, drop, or paste media first','error');return;}if(state.pendingDrop?.type==='image'&&!pendingFiles().length){toast('Add at least one image','error');return;}commitTagInput();const form=new FormData(els.contentForm);pendingFiles().forEach(file=>form.append('draggedFiles[]',file));if(state.pendingThumbnail)form.set('thumbnail',state.pendingThumbnail,state.pendingThumbnail.name||'thumbnail.png');form.set('tags',state.pendingTags.join(','));form.set('section',state.section);try{const tile=await api.createTile(form);state.tiles.unshift(tile);els.contentModal.close();state.pendingDrop=null;revokePreviewUrls();renderTiles();toast('Content added');}catch(error){toast(error.message,'error');}}
async function persistBookmarks(){try{await api.saveBookmarks(state.bookmarks);}catch(error){toast(error.message,'error');}}

function viewerMediaMarkup(tile){
  if(tile.type==='image')return `<div class="viewer-gallery">${(tile.files||[]).map(src=>`<img src="${escapeHtml(src)}" alt="${escapeHtml(tile.label||'Image')}" />`).join('')}</div>`;
  if(tile.type==='video'&&tile.files?.[0])return `<video src="${escapeHtml(tile.files[0])}" controls autoplay playsinline></video>`;
  if(tile.type==='audio'&&tile.files?.[0])return `<div class="viewer-audio">${tile.thumbnail?`<img src="${escapeHtml(tile.thumbnail)}" alt="">`:''}<audio src="${escapeHtml(tile.files[0])}" controls autoplay></audio></div>`;
  if(tile.type==='text'){const s=tile.textStyle||{};return `<div class="viewer-text" style="font-family:${escapeHtml(s.font||'inherit')};font-size:${Math.max(22,Number(s.fontSize||28))}px;font-weight:${s.bold?700:500};font-style:${s.italic?'italic':'normal'};text-decoration:${s.underline?'underline':'none'};text-align:${escapeHtml(s.align||'left')}">${escapeHtml(tile.text||'')}</div>`;}
  if(tile.files?.[0])return `<div class="viewer-file"><div class="file-symbol">${tile.type==='font'?'Aa':'↗'}</div><a class="btn btn--primary" href="${escapeHtml(tile.files[0])}" target="_blank" rel="noreferrer">Open file</a></div>`;
  return '';
}
function openViewer(tile){els.viewerMedia.innerHTML=viewerMediaMarkup(tile);els.viewerMeta.innerHTML=`<div class="eyebrow">${escapeHtml(tile.type)}</div><h2>${escapeHtml(tile.label||defaultTileLabel(tile))}</h2>${tile.description?`<p>${escapeHtml(tile.description)}</p>`:''}${tile.tags?.length?`<div class="viewer-tags">${tile.tags.map(t=>`<span>${escapeHtml(t)}</span>`).join('')}</div>`:''}`;els.mediaViewer.showModal();}
function activateTile(tileId){const tile=state.tiles.find(t=>t.id===tileId);if(!tile)return;if(tile.type==='link'&&tile.url){window.open(tile.url,'_blank','noopener,noreferrer');return;}if(MEDIA_TYPES.has(tile.type))openViewer(tile);}

function handleModalImages(images){
  if(!images.length)return;
  if(state.pendingDrop.type==='text'||['video','audio','font','file','link'].includes(state.pendingDrop.type)){state.pendingThumbnail=images[0];refreshDynamicFields();return;}
  if(state.pendingDrop.type==='media')state.pendingDrop={type:'image',files:[]};
  if(state.pendingDrop.type==='image'){state.pendingDrop.files.push(...images);refreshDynamicFields();}
}
function handleModalFiles(files){
  const images=files.filter(f=>f.type.startsWith('image/'));
  if(state.pendingDrop.type==='text'){if(images[0]){state.pendingThumbnail=images[0];refreshDynamicFields();}return;}
  if(state.pendingDrop.type==='image'){if(images.length){state.pendingDrop.files.push(...images);refreshDynamicFields();}else toast('Only images can be added to this gallery','error');return;}
  if(state.pendingDrop.type==='media'){const detected=detectFiles(files);if(detected){state.pendingDrop=detected;refreshDynamicFields();}return;}
  if(images.length){state.pendingThumbnail=images[0];refreshDynamicFields();return;}
  const detected=detectFiles(files);if(detected){state.pendingDrop=detected;refreshDynamicFields();}
}

function setupDragAndDrop(){let dragDepth=0;window.addEventListener('dragenter',e=>{if(els.contentModal.open)return;if($('[data-tile-id].is-dragging')||$('.bookmark-item.is-dragging'))return;e.preventDefault();dragDepth++;els.dragOverlay.classList.add('is-visible');});window.addEventListener('dragover',e=>{if(els.contentModal.open)return;if($('[data-tile-id].is-dragging')||$('.bookmark-item.is-dragging'))return;e.preventDefault();});window.addEventListener('dragleave',()=>{dragDepth--;if(dragDepth<=0){dragDepth=0;els.dragOverlay.classList.remove('is-visible');}});window.addEventListener('drop',e=>{if(els.contentModal.open)return;if($('[data-tile-id].is-dragging')||$('.bookmark-item.is-dragging'))return;e.preventDefault();dragDepth=0;els.dragOverlay.classList.remove('is-visible');const pending=detectDrop(e.dataTransfer);pending?openContentModal(pending):toast('That drop type is not supported','error');});
  document.addEventListener('dragstart',e=>{const tile=e.target.closest('[data-tile-id]');const bookmark=e.target.closest('[data-bookmark-id]');if(tile){tile.classList.add('is-dragging');e.dataTransfer.effectAllowed='copyMove';e.dataTransfer.setData('application/x-comma-tile',tile.dataset.tileId);}else if(bookmark){bookmark.classList.add('is-dragging');e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('application/x-comma-bookmark',bookmark.dataset.bookmarkId);}});document.addEventListener('dragend',e=>{e.target.closest('.is-dragging')?.classList.remove('is-dragging');$$('.bookmark-item').forEach(x=>x.classList.remove('drop-before','drop-after'));});
  els.bookmarks.addEventListener('dragover',e=>{const tileId=e.dataTransfer.getData('application/x-comma-tile');const bookmarkId=e.dataTransfer.getData('application/x-comma-bookmark');if(!tileId&&!bookmarkId)return;e.preventDefault();e.stopPropagation();els.bookmarksPanel.classList.add('is-drop-target');if(bookmarkId){const target=e.target.closest('.bookmark-item');$$('.bookmark-item',els.bookmarks).forEach(x=>x.classList.remove('drop-before','drop-after'));if(target&&target.dataset.bookmarkId!==bookmarkId){const r=target.getBoundingClientRect();target.classList.add(e.clientY<r.top+r.height/2?'drop-before':'drop-after');}}});
  els.bookmarks.addEventListener('dragleave',e=>{if(!els.bookmarks.contains(e.relatedTarget))els.bookmarksPanel.classList.remove('is-drop-target');});els.bookmarks.addEventListener('drop',async e=>{e.preventDefault();e.stopPropagation();els.bookmarksPanel.classList.remove('is-drop-target');const tileId=e.dataTransfer.getData('application/x-comma-tile');const bookmarkId=e.dataTransfer.getData('application/x-comma-bookmark');const target=e.target.closest('.bookmark-item');if(tileId){if(!state.bookmarks.includes(tileId)){const i=target?state.bookmarks.indexOf(target.dataset.bookmarkId):state.bookmarks.length;state.bookmarks.splice(i<0?state.bookmarks.length:i,0,tileId);renderBookmarks();await persistBookmarks();toast('Added to bookmarks');}return;}if(bookmarkId){const from=state.bookmarks.indexOf(bookmarkId);if(from<0)return;state.bookmarks.splice(from,1);let to=target?state.bookmarks.indexOf(target.dataset.bookmarkId):state.bookmarks.length;if(target?.classList.contains('drop-after'))to++;state.bookmarks.splice(Math.max(0,to),0,bookmarkId);renderBookmarks();await persistBookmarks();}});
}

function bindEvents(){
  document.addEventListener('click',async e=>{
    const tag=e.target.closest('[data-tag]');if(tag){state.tag=tag.dataset.tag;renderTags();renderTiles();return;}
    const themeChoice=e.target.closest('[data-theme-choice]');if(themeChoice){state.settings.theme=themeChoice.dataset.themeChoice;applyTheme();try{await api.saveSettings(state.settings);}catch(err){toast(err.message,'error');}return;}
    const nav=e.target.closest('[data-section]');if(nav?.classList.contains('nav-tab')){setSection(nav.dataset.section);return;}
    if(e.target.closest('#addTopLink')){els.topLinkForm.reset();els.topLinkModal.showModal();return;}
    const close=e.target.closest('[data-close]');if(close){document.getElementById(close.dataset.close)?.close();return;}
    const preset=e.target.closest('[data-preset-tag]');if(preset){addTag(preset.dataset.presetTag);return;}
    const removeFormTag=e.target.closest('[data-remove-form-tag]');if(removeFormTag){state.pendingTags=state.pendingTags.filter(t=>t!==removeFormTag.dataset.removeFormTag);renderTagEditor();return;}
    const trigger=e.target.closest('[data-file-trigger]');if(trigger){document.getElementById(trigger.dataset.fileTrigger)?.click();return;}
    const galleryAdd=e.target.closest('#galleryAdd');if(galleryAdd){$('#galleryFileInput')?.click();return;}
    if(e.target.closest('#thumbnailAdd')){$('#thumbnailPickerInput')?.click();return;}
    if(e.target.closest('#chooseMediaButton')){els.contentFilePicker.value='';els.contentFilePicker.click();return;}
    const choice=e.target.closest('[data-content-choice]');if(choice){els.contentTypeModal.close();if(choice.dataset.contentChoice==='media'){openContentModal({type:'media',files:[]});}else if(choice.dataset.contentChoice==='link'){openContentModal({type:'link',url:''});}else{openContentModal({type:'text',text:''});}return;}
    const removePending=e.target.closest('[data-remove-pending-file]');if(removePending){state.pendingDrop.files.splice(Number(removePending.dataset.removePendingFile),1);refreshDynamicFields();return;}
    if(e.target.closest('[data-remove-thumbnail]')){state.pendingThumbnail=null;refreshDynamicFields();return;}
    const removeBookmark=e.target.closest('[data-remove-bookmark]');if(removeBookmark){state.bookmarks=state.bookmarks.filter(id=>id!==removeBookmark.dataset.removeBookmark);renderBookmarks();await persistBookmarks();return;}
    const deleteTile=e.target.closest('[data-delete-tile]');if(deleteTile){e.preventDefault();e.stopPropagation();if(!confirm('Delete this tile?'))return;try{await api.deleteTile(deleteTile.dataset.deleteTile);state.tiles=state.tiles.filter(t=>t.id!==deleteTile.dataset.deleteTile);state.bookmarks=state.bookmarks.filter(id=>id!==deleteTile.dataset.deleteTile);renderTiles();renderBookmarks();toast('Tile deleted');}catch(err){toast(err.message,'error');}return;}
    const tile=e.target.closest('[data-tile-id]');if(tile){activateTile(tile.dataset.tileId);}
  });
  document.addEventListener('keydown',e=>{if(e.target===els.tagInput&&(e.key==='Enter'||e.key===','||e.key===' ')){e.preventDefault();commitTagInput();}const tile=e.target.closest?.('[data-tile-id]');if(tile&&(e.key==='Enter'||e.key===' ')){e.preventDefault();activateTile(tile.dataset.tileId);}});
  document.addEventListener('change',e=>{
    if(e.target?.id==='galleryFileInput'){state.pendingDrop.files.push(...[...e.target.files].filter(f=>f.type.startsWith('image/')));refreshDynamicFields();return;}
    if(e.target?.id==='thumbnailPickerInput'&&e.target.files?.[0]){state.pendingThumbnail=e.target.files[0];refreshDynamicFields();return;}
    if(e.target?.id==='replacementFileInput'&&e.target.files?.length){state.pendingDrop.files=[...e.target.files];refreshDynamicFields();return;}
    if(e.target?.type==='file'){const label=document.querySelector(`[data-file-name="${e.target.id}"]`);if(label)label.textContent=e.target.files?.length?([...e.target.files].map(f=>f.name).join(', ')):'No file selected';}
    if(state.pendingDrop?.type==='text'&&e.target.closest('#contentForm'))updateTextPreview();
  });
  els.contentForm.addEventListener('input',e=>{if(state.pendingDrop?.type==='text'&&e.target.matches('[name="text"],[name="fontSize"]'))updateTextPreview();});
  els.search.addEventListener('input',()=>{state.query=els.search.value.trim();els.clearSearch.classList.toggle('is-visible',!!state.query);renderTiles();});els.clearSearch.addEventListener('click',()=>{els.search.value='';state.query='';els.clearSearch.classList.remove('is-visible');els.search.focus();renderTiles();});
  els.settingsButton.addEventListener('click',()=>els.settingsModal.showModal());els.modeToggle.addEventListener('change',async()=>{state.settings.mode=els.modeToggle.checked?'dark':'light';applyTheme();try{await api.saveSettings(state.settings);}catch(e){toast(e.message,'error');}});
  els.contentAddButton.addEventListener('click',()=>els.contentTypeModal.showModal());els.contentFilePicker.addEventListener('change',()=>{const pending=detectFiles(els.contentFilePicker.files);if(!pending)return;if(els.contentModal.open&&state.pendingDrop?.type==='media'){state.pendingDrop=pending;refreshDynamicFields();}else openContentModal(pending);});
  els.contentForm.addEventListener('submit',handleContentSubmit);els.topLinkForm.addEventListener('submit',async e=>{e.preventDefault();try{const link=await api.createTopLink(new FormData(els.topLinkForm));state.topLinks.push(link);renderTopLinks();els.topLinkModal.close();toast('Top link added');}catch(err){toast(err.message,'error');}});
  [els.contentTypeModal,els.contentModal,els.topLinkModal,els.settingsModal,els.mediaViewer].forEach(dialog=>dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close();}));
  els.contentModal.addEventListener('dragover',e=>{if(!state.pendingDrop)return;e.preventDefault();e.stopPropagation();els.contentModal.querySelector('.modal-card')?.classList.add('is-modal-drop-target');});
  els.contentModal.addEventListener('dragleave',e=>{if(!els.contentModal.contains(e.relatedTarget))els.contentModal.querySelector('.modal-card')?.classList.remove('is-modal-drop-target');});
  els.contentModal.addEventListener('drop',e=>{if(!state.pendingDrop)return;e.preventDefault();e.stopPropagation();els.contentModal.querySelector('.modal-card')?.classList.remove('is-modal-drop-target');const files=[...(e.dataTransfer?.files||[])];if(!files.length)return;handleModalFiles(files);});
  document.addEventListener('paste',e=>{if(!els.contentModal.open||!state.pendingDrop||!['media','image','video','audio','font','file','text'].includes(state.pendingDrop.type))return;const images=[...(e.clipboardData?.files||[])].filter(f=>f.type.startsWith('image/'));if(!images.length)return;e.preventDefault();handleModalImages(images);});
  els.contentModal.addEventListener('close',()=>{revokePreviewUrls();state.pendingTags=[];state.pendingThumbnail=null;});
}

async function init(){try{Object.assign(state,await api.bootstrap());}catch(error){toast('Could not load PHP data. Serve this folder through PHP.','error');}applyTheme();renderAll();bindEvents();setupDragAndDrop();}
init();
